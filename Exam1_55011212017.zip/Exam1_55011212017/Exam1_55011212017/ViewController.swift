//
//  ViewController.swift
//  Exam1_55011212017
//
//  Created by student on 10/10/14.
//  Copyright (c) 2014 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableview: UITableView!
    
    @IBOutlet var show: UILabel!
    @IBOutlet var inputPrice: UITextField!
    @IBOutlet var inputVolume: UITextField!
    @IBOutlet var inputName: UITextField!
    @IBOutlet weak var total: UITextField!
    @IBOutlet var totalOutput: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func Buttontotal(sender: AnyObject) {
        var name = inputName.text
        var a = inputVolume.text.toInt()
        var b = inputPrice.text.toInt()
        
        

        var sum =  a! * b!
        
        totalOutput.text = "\(sum)"
        
    }

}

